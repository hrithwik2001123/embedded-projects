#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,j,i,k;
    printf("enter a limit ");
    scanf("%d",&n);
    int s[n];
    int s1[n];

        for(j=2;j<n;j++)
        {
            for(k=0;s[k]!=n;k++)
            {
                if (j%2!=0||j==2)
            {
               s[k]=j;

            }
            }

        }
 for(k=0;s[k]<n;k++)
            {
                printf("%d",s[k]);
            }

   for(j=2;j<n;j++)
        {
            for(k=0;s[k]<n;k++)
            {
                if (j/2==0)
            {
               s1[k]=j;

            }
            }

        }
         for(k=0;s[k]<n;k++)
            {

               printf("%d",s[k]);

            }

}
