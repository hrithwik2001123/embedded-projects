#include <stdio.h>
#include <stdlib.h>

int main()
{


FILE*ptr=NULL;
ptr=fopen("new-2.text","w");
char ch[]="string";
if (ptr==NULL)
{
    printf("error\n");

}
fputs(ch,ptr);
fclose(ptr);
}
