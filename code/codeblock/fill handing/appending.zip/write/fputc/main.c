#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE*fptr=NULL;
    fptr=fopen("new.text","w");
    char ch='b';
    if (fptr==NULL)
    {
       printf("error\n");
    }

     fputc(ch,fptr);
     fclose(fptr);
}
