ucos_ii.o ucos_ii.d : /home/sarin/ucos-II/software/ucos-ii/source/ucos_ii.c \
  includes.h os_cpu.h os_cfg.h \
  /home/sarin/ucos-II/software/ucos-ii/source/ucos_ii.h \
  /home/sarin/Micrium/Software/uCOS-II/Ports/AVR/ATmega128/GNU/jlu/avr_isr.h \
  /home/sarin/ucos-II/software/ucos-ii/source/os_core.c \
  /home/sarin/ucos-II/software/ucos-ii/source/os_flag.c \
  /home/sarin/ucos-II/software/ucos-ii/source/os_mbox.c \
  /home/sarin/ucos-II/software/ucos-ii/source/os_mem.c \
  /home/sarin/ucos-II/software/ucos-ii/source/os_mutex.c \
  /home/sarin/ucos-II/software/ucos-ii/source/os_q.c \
  /home/sarin/ucos-II/software/ucos-ii/source/os_sem.c \
  /home/sarin/ucos-II/software/ucos-ii/source/os_task.c \
  /home/sarin/ucos-II/software/ucos-ii/source/os_time.c
