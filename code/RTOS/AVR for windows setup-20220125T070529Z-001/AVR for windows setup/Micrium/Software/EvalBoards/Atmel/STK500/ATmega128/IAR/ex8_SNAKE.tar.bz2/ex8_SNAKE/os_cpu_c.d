os_cpu_c.o os_cpu_c.d : \
 /home/sarin/Micrium/Software/uCOS-II/Ports/AVR/ATmega128/GNU/jlu/os_cpu_c.c \
  includes.h os_cpu.h os_cfg.h \
  /home/sarin/ucos-II/software/ucos-ii/source/ucos_ii.h \
  /home/sarin/Micrium/Software/uCOS-II/Ports/AVR/ATmega128/GNU/jlu/avr_isr.h
