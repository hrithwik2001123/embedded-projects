test2.o test2.d : test2.c includes.h os_cpu.h os_cfg.h \
  /home/sarin/ucos-II/software/ucos-ii/source/ucos_ii.h \
  /home/sarin/Micrium/Software/uCOS-II/Ports/AVR/ATmega128/GNU/jlu/avr_isr.h \
  VT102lib.h myUART.h
