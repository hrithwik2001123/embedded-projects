sample.o sample.d : sample.c includes.h os_cpu.h os_cfg.h \
  c:/Micrium/Micrium/SOFTWARE/uCOS-II/Source/ucos_ii.h \
  c:/Micrium/Micrium/SOFTWARE/uCOS-II/Ports/AVR/ATmega128/GNU/jlu/avr_isr.h \
  LCD_mega128.h
